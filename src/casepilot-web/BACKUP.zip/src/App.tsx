import { useState } from "react"
import OrderDetails from "./components/OrderDetails"
import FoodAlertSearch from "./components/FoodAlertSearch"
import "./App.css"

type SupportCase = {
  id: number
  orderNumber: string
  subject: string
  description: string
}

export default function App() {
  const [supportCase, setSupportCase] = useState<SupportCase | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function loadCase() {
    setLoading(true)
    setError(null)
    setSupportCase(null)

    try {
      const response = await fetch("/api/cases/1")

      if (!response.ok) {
        throw new Error(`Case request failed (${response.status})`)
      }

      const data: SupportCase = await response.json()
      setSupportCase(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load the case.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <main>
      <h1>CasePilot</h1>
      <p>Customer support investigation workspace</p>

      <button onClick={loadCase} disabled={loading}>
        {loading ? "Loading…" : "Load case"}
      </button>

      {error && <p role="alert">{error}</p>}

      <FoodAlertSearch />
      {supportCase && (
        <article className="card">
          <h2>
            Case #{supportCase.id}: {supportCase.subject}
          </h2>
          <p>
            {/* <p>{supportCase.description}</p> */}
            <strong>Order:</strong> {supportCase.orderNumber}
          </p>
          <p>{supportCase.description}</p>
        </article>
      )}
    </main>
  )
}
