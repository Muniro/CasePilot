import { useState } from "react"
import type { FormEvent } from "react"
import "./FoodAlertSearch.css"
import { Button, Stack, TextField } from "@mui/material"

type FoodAlert = {
  notation: string
  title: string
  description: string | null
  alertUrl: string | null
  modified: string | null
}

export default function FoodAlertSearch() {
  const [query, setQuery] = useState("Healthy Fit")
  const [alerts, setAlerts] = useState<FoodAlert[] | null>(null)
  const [selected, setSelected] = useState<FoodAlert | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function search(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()

    const searchText = query.trim()
    if (!searchText || loading) return

    setLoading(true)
    setError(null)
    setAlerts(null)
    setSelected(null)

    try {
      const response = await fetch(`/api/alerts?query=${encodeURIComponent(searchText)}`)

      if (!response.ok) {
        const problem = await response.json().catch(() => null)
        throw new Error(problem?.title ?? `Search failed (${response.status})`)
      }

      const results: FoodAlert[] = await response.json()
      setAlerts(results)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not search alerts.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <section className="food-alerts">
      <header>
        <span className="food-alerts__eyebrow">LIVE FSA DATA</span>
        <h2>Food recall investigation</h2>
        <p>Search the 100 most recently modified food alerts.</p>
      </header>

      <form onSubmit={search}>
        <Stack direction={{ xs: "column", sm: "row" }} spacing={2} sx={{ my: 3 }}>
          <TextField id="alert-query" label="Product or brand" placeholder="For example: Healthy Fit" value={query} onChange={event => setQuery(event.target.value)} slotProps={{ htmlInput: { maxLength: 100 } }} fullWidth required disabled={loading} sx={{ bgcolor: "background.paper", borderRadius: 1 }} />

          <Button type="submit" variant="contained" disabled={loading || !query.trim()} sx={{ minWidth: 160 }}>
            {loading ? "Searching…" : "Search alerts"}
          </Button>
        </Stack>
      </form>
      {error && <p role="alert">{error}</p>}

      {alerts !== null && (
        <>
          <p role="status">{alerts.length === 0 ? "No matching alerts within this recent set." : `${alerts.length} matching alert(s). Select one to investigate.`}</p>

          <div className="food-alerts__workspace">
            <div className="food-alerts__results">
              {alerts.map(alert => (
                <button key={alert.notation} type="button" className="food-alerts__result" aria-pressed={selected?.notation === alert.notation} onClick={() => setSelected(alert)}>
                  <small>{alert.notation}</small>
                  <strong>{alert.title}</strong>
                </button>
              ))}
            </div>

            <aside className="food-alerts__details">
              {selected ? (
                <>
                  <h3>{selected.title}</h3>
                  <p>{selected.description}</p>

                  {selected.modified && <p>Updated: {new Date(selected.modified).toLocaleDateString("en-GB")}</p>}

                  {selected.alertUrl && (
                    <a href={selected.alertUrl} target="_blank" rel="noopener noreferrer">
                      Read official FSA notice ↗
                    </a>
                  )}
                </>
              ) : (
                <p>Select an alert to view its details.</p>
              )}
            </aside>
          </div>
        </>
      )}
    </section>
  )
}
