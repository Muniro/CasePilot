import { useState } from "react"

type Order = {
  orderNumber: string
  status: string
  promisedDeliveryDate: string
  revisedDeliveryDate: string | null
  delayReason: string | null
}

export default function OrderDetails({ orderNumber }: { orderNumber: string }) {
  const [order, setOrder] = useState<Order | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function loadOrder() {
    setLoading(true)
    setError(null)
    setOrder(null)

    try {
      const response = await fetch(`/api/orders/${encodeURIComponent(orderNumber)}`)

      if (response.status === 404) {
        throw new Error("Order not found.")
      }

      if (!response.ok) {
        throw new Error(`Order request failed (${response.status})`)
      }

      const data: Order = await response.json()
      setOrder(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load the order.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <section>
      <h3>Order evidence</h3>

      <button onClick={loadOrder} disabled={loading}>
        {loading ? "Looking up…" : "Look up order"}
      </button>

      {error && <p role="alert">{error}</p>}

      {order && (
        <div>
          <p>
            <strong>Status:</strong> {order.status}
          </p>
          <p>
            <strong>Originally due:</strong> {order.promisedDeliveryDate}
          </p>
          <p>
            <strong>Revised delivery:</strong> {order.revisedDeliveryDate ?? "Not confirmed"}
          </p>
          <p>
            <strong>Delay reason:</strong> {order.delayReason ?? "Not recorded"}
          </p>
        </div>
      )}
    </section>
  )
}
