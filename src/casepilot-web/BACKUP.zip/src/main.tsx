import { StrictMode } from "react"
import { createRoot } from "react-dom/client"
import CssBaseline from "@mui/material/CssBaseline"
import { createTheme, ThemeProvider } from "@mui/material/styles"
import App from "./App.tsx"

const theme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#2455c7"
    },
    background: {
      default: "#eef2f8",
      paper: "#ffffff"
    },
    text: {
      primary: "#17243b",
      secondary: "#52627a"
    }
  },
  typography: {
    fontFamily: '"Segoe UI", Arial, sans-serif',
    button: {
      textTransform: "none",
      fontWeight: 600
    }
  },
  shape: {
    borderRadius: 10
  }
})

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <App />
    </ThemeProvider>
  </StrictMode>
)
